const express = require('express');
const router = express.Router();
const db = require('../database');

// Authentication Middleware
const requireAuth = (req, res, next) => {
    if (req.session && req.session.authenticated) {
        return next();
    }
    return res.status(401).json({ error: 'Unauthorized' });
};

// Login Route
router.post('/login', (req, res) => {
    const { password } = req.body;
    if (password === process.env.APP_PASSWORD) {
        req.session.authenticated = true;
        return res.json({ success: true });
    }
    return res.status(401).json({ success: false, error: 'Invalid password' });
});

// Logout Route
router.post('/logout', (req, res) => {
    req.session.destroy();
    res.json({ success: true });
});

// Status Route
router.get('/status', (req, res) => {
    if (req.session && req.session.authenticated) {
        return res.json({ authenticated: true });
    }
    return res.json({ authenticated: false });
});

// ----------------------------------------------------------------------------
// Protected Routes
// ----------------------------------------------------------------------------
router.use(requireAuth);

// Get all notes
router.get('/notes', (req, res) => {
    try {
        const notes = db.getNotes();
        notes.sort((a, b) => new Date(b.updated_at) - new Date(a.updated_at));
        res.json(notes);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Create note
router.post('/notes', (req, res) => {
    const { title, content } = req.body;
    if (!title || content === undefined) {
        return res.status(400).json({ error: 'Title and content are required' });
    }

    try {
        const notes = db.getNotes();
        const newId = notes.length > 0 ? Math.max(...notes.map(n => n.id)) + 1 : 1;
        const now = new Date().toISOString();

        const newNote = {
            id: newId,
            title,
            content,
            created_at: now,
            updated_at: now
        };

        notes.push(newNote);
        db.saveNotes(notes);

        res.status(201).json(newNote);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Update note
router.put('/notes/:id', (req, res) => {
    const id = parseInt(req.params.id, 10);
    const { title, content } = req.body;

    if (!title || content === undefined) {
        return res.status(400).json({ error: 'Title and content are required' });
    }

    try {
        const notes = db.getNotes();
        const index = notes.findIndex(n => n.id === id);

        if (index === -1) {
            return res.status(404).json({ error: 'Note not found' });
        }

        notes[index].title = title;
        notes[index].content = content;
        notes[index].updated_at = new Date().toISOString();

        db.saveNotes(notes);
        res.json(notes[index]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Delete note
router.delete('/notes/:id', (req, res) => {
    const id = parseInt(req.params.id, 10);

    try {
        const notes = db.getNotes();
        const initialLength = notes.length;

        const newNotes = notes.filter(n => n.id !== id);

        if (newNotes.length === initialLength) {
            return res.status(404).json({ error: 'Note not found' });
        }

        db.saveNotes(newNotes);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;
