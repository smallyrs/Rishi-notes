// State
let currentNoteId = null;
let notes = [];

// DOM Elements
const screens = {
    login: document.getElementById('login-screen'),
    dashboard: document.getElementById('dashboard-screen')
};

const loginForm = document.getElementById('login-form');
const passwordInput = document.getElementById('password-input');
const loginError = document.getElementById('login-error');
const logoutBtn = document.getElementById('logout-btn');

const notesListEl = document.getElementById('notes-list');
const newNoteBtn = document.getElementById('new-note-btn');
const editorContainer = document.getElementById('editor-container');
const editorPlaceholder = document.getElementById('editor-placeholder');
const noteTitleInput = document.getElementById('note-title');
const noteContentInput = document.getElementById('note-content');
const saveNoteBtn = document.getElementById('save-note-btn');
const deleteNoteBtn = document.getElementById('delete-note-btn');
const saveStatus = document.getElementById('save-status');

// Init
checkStatus();

// API Functions
async function apiCall(endpoint, method = 'GET', body = null) {
    const options = {
        method,
        headers: { 'Content-Type': 'application/json' },
    };
    if (body) options.body = JSON.stringify(body);

    const response = await fetch(`/api${endpoint}`, options);
    const data = await response.json();

    if (response.status === 401 && endpoint !== '/status') {
        showScreen('login');
        return null;
    }

    if (!response.ok) {
        throw new Error(data.error || 'API Error');
    }

    return data;
}

async function checkStatus() {
    try {
        const data = await apiCall('/status');
        if (data && data.authenticated) {
            showScreen('dashboard');
            loadNotes();
        } else {
            showScreen('login');
        }
    } catch (e) {
        showScreen('login');
    }
}

function showScreen(screenName) {
    Object.values(screens).forEach(s => s.classList.add('hidden'));
    screens[screenName].classList.remove('hidden');
    if (screenName === 'login') passwordInput.focus();
}

// Event Listeners: Auth
loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    loginError.textContent = '';
    const password = passwordInput.value;

    try {
        const data = await apiCall('/login', 'POST', { password });
        if (data && data.success) {
            passwordInput.value = '';
            showScreen('dashboard');
            loadNotes();
        }
    } catch (err) {
        loginError.textContent = 'Invalid password';
    }
});

logoutBtn.addEventListener('click', async () => {
    await apiCall('/logout', 'POST');
    showScreen('login');
});

// Event Listeners: Notes
newNoteBtn.addEventListener('click', () => {
    currentNoteId = null;
    noteTitleInput.value = '';
    noteContentInput.value = '';
    showEditor();
    noteTitleInput.focus();
    renderNotesList(); // update active state
});

saveNoteBtn.addEventListener('click', saveCurrentNote);

deleteNoteBtn.addEventListener('click', async () => {
    if (!currentNoteId) return;
    if (!confirm('Are you sure you want to delete this note?')) return;

    try {
        await apiCall(`/notes/${currentNoteId}`, 'DELETE');
        notes = notes.filter(n => n.id !== currentNoteId);
        currentNoteId = null;
        hideEditor();
        renderNotesList();
    } catch (e) {
        alert('Failed to delete note');
    }
});

document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        if (currentNoteId !== null || (noteTitleInput.value && noteContentInput.value)) {
            saveCurrentNote();
        }
    }
});

// Notes Logic
async function loadNotes() {
    try {
        notes = await apiCall('/notes');
        renderNotesList();
    } catch (e) {
        console.error('Failed to load notes', e);
    }
}

function renderNotesList() {
    notesListEl.innerHTML = '';
    if (!notes || notes.length === 0) {
        notesListEl.innerHTML = '<div style="color: var(--text-secondary); padding: 1rem; text-align: center;">No notes yet.</div>';
        return;
    }

    notes.forEach(note => {
        const div = document.createElement('div');
        div.className = `note-item ${note.id === currentNoteId ? 'active' : ''}`;

        let dateStr = '';
        if (note.updated_at) {
            dateStr = new Date(note.updated_at).toLocaleDateString();
        }

        div.innerHTML = `
            <div class="note-item-title">${escapeHTML(note.title)}</div>
            <div class="note-item-date">${dateStr}</div>
        `;

        div.addEventListener('click', () => selectNote(note.id));
        notesListEl.appendChild(div);
    });
}

function selectNote(id) {
    const note = notes.find(n => n.id === id);
    if (!note) return;

    currentNoteId = note.id;
    noteTitleInput.value = note.title;
    noteContentInput.value = note.content;
    showEditor();
    renderNotesList(); // Update active state
}

async function saveCurrentNote() {
    const title = noteTitleInput.value.trim();
    const content = noteContentInput.value.trim();

    if (!title) {
        saveStatus.textContent = 'Title is required';
        saveStatus.style.color = 'var(--danger-color)';
        setTimeout(() => saveStatus.textContent = '', 3000);
        return;
    }

    saveNoteBtn.textContent = 'Saving...';
    saveNoteBtn.disabled = true;

    try {
        let savedNote;
        if (currentNoteId) {
            savedNote = await apiCall(`/notes/${currentNoteId}`, 'PUT', { title, content });
            notes = notes.map(n => n.id === currentNoteId ? savedNote : n);
        } else {
            savedNote = await apiCall('/notes', 'POST', { title, content });
            notes.unshift(savedNote);
            currentNoteId = savedNote.id;
        }

        renderNotesList();

        saveStatus.textContent = 'Saved successfully!';
        saveStatus.style.color = 'var(--text-secondary)';
    } catch (e) {
        saveStatus.textContent = 'Failed to save';
        saveStatus.style.color = 'var(--danger-color)';
    } finally {
        saveNoteBtn.textContent = 'Save Note';
        saveNoteBtn.disabled = false;
        setTimeout(() => saveStatus.textContent = '', 3000);
    }
}

function showEditor() {
    editorPlaceholder.classList.add('hidden');
    editorContainer.classList.remove('hidden');
    deleteNoteBtn.style.visibility = currentNoteId ? 'visible' : 'hidden';
}

function hideEditor() {
    editorContainer.classList.add('hidden');
    editorPlaceholder.classList.remove('hidden');
}

function escapeHTML(str) {
    return str.replace(/[&<>'"]/g,
        tag => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            "'": '&#39;',
            '"': '&quot;'
        }[tag] || tag)
    );
}
